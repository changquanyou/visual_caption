# -*- coding:utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals  # compatible with python3 unicode coding

import tensorflow as tf

from tf_visgen.base.data.base_data_reader import BaseDataReader
from tf_visgen.mscoco.data.mscoco_data_config import MSCOCODataConfig


class MSCOCODataReader(BaseDataReader):
    """
    read tf_example from mscoco tfrecord file ,
    convert tf_example data into tf.data.Dataset format
\
    """

    def __init__(self, data_config):
        super(MSCOCODataReader, self).__init__(
            data_config=data_config)

    def _mapping_dataset(self, dataset):
        num_threads = self.data_config.num_preprocess_threads

        output_buffer_size = self.data_config.output_buffer_size
        random_seed = self.data_config.random_seed

        dataset = dataset.shuffle(buffer_size=output_buffer_size,
                                  seed=random_seed)

        def batching_func(x):
            return x.padded_batch(
                batch_size=self.data_config.batch_size,
                padded_shapes=(
                    tf.TensorShape([]),  # image_id
                    tf.TensorShape([]),  # width
                    tf.TensorShape([]),  # height
                    tf.TensorShape([]),  # depth
                    tf.TensorShape([1536]),  # image_feature
                    # tf.TensorShape([]),  # image_rawdata
                    tf.TensorShape([None]),  # image_bbox_shape
                    #
                    tf.TensorShape([]),  # number
                    tf.TensorShape([None]),  # labels
                    tf.TensorShape([None]),  # bboxes
                    # tf.TensorShape([None]),  # image_bbox_shape
                    tf.TensorShape([None, None])  # image_bbox_features

                )
            )

        dataset = batching_func(dataset)
        return dataset
        pass

    def _build_context_and_feature(self):
        self.context_features = {
            'image/image_id': tf.FixedLenFeature([], dtype=tf.int64),
            'image/height': tf.FixedLenFeature([], dtype=tf.int64),
            'image/width': tf.FixedLenFeature([], dtype=tf.int64),
            'image/depth': tf.FixedLenFeature([], dtype=tf.int64),
            'image/feature': tf.FixedLenFeature([], dtype=tf.string),

            'bbox/number': tf.FixedLenFeature([], dtype=tf.int64),
            'bbox/labels': tf.VarLenFeature(tf.int64),
            'bbox/bboxes': tf.VarLenFeature(tf.int64),
            'bbox/features': tf.FixedLenFeature([], dtype=tf.string),
        }
        self.sequence_features = {
            # 'image/captions': tf.FixedLenSequenceFeature([], dtype=tf.string),
        }
        pass

    def _parse_tf_example(self, serialized_example):
        # parsing sequence example
        context, sequence = tf.parse_single_sequence_example(
            serialized_example,
            context_features=self.context_features,
            sequence_features=self.sequence_features
        )
        image_id = context['image/image_id']
        image_height = tf.cast(context['image/height'], tf.int32)
        image_width = tf.cast(context['image/width'], tf.int32)
        image_depth = tf.cast(context['image/depth'], tf.int32)

        # image_rawdata = tf.decode_raw(context['image/raw_data'], tf.float32)
        # image_shape = tf.stack([image_height, image_width, image_depth])
        # image_rawdata = tf.reshape(image_rawdata, image_shape)

        image_feature = tf.decode_raw(context['image/feature'], tf.float32)

        # # Since information about shape is lost reshape it
        bbox_number = tf.cast(context['bbox/number'], tf.int32)
        bbox_labels = tf.sparse_tensor_to_dense(context['bbox/labels'], default_value=0)
        bboxes = tf.sparse_tensor_to_dense(context['bbox/bboxes'], default_value=0)
        # bboxes_shape = tf.stack([bbox_number, 4])
        # bboxes = tf.reshape(bboxes, bboxes_shape)


        bbox_features = context['bbox/features']
        bbox_features = tf.decode_raw(bbox_features, tf.float32)
        # bbox_features = tf.sparse_tensor_to_dense(context['bbox/features'], default_value=0)
        bbox_features_shape = tf.stack([bbox_number, self.data_config.dim_visual_feature])
        bbox_features = tf.reshape(bbox_features, bbox_features_shape)

        parsed_example = (image_id, image_height, image_width, image_depth,
                          image_feature,
                          # image_rawdata,
                          bbox_features_shape,
                          bbox_number, bbox_labels, bboxes, bbox_features)

        return parsed_example
        pass

    pass


def main(_):
    data_config = MSCOCODataConfig()
    data_reader = MSCOCODataReader(data_config=data_config)

    next_batch = data_reader.get_next_batch(batch_size=10)
    train_op = data_reader.get_train_init_op()
    with tf.Session() as sess:
        sess.run(train_op)
        step = 0
        while True:
            try:
                batch_data = sess.run(next_batch)
                # print(batch_data)
                id_batch, width_batch, height_batch, depth_batch, \
                feature_batch, shape_batch, \
                bbox_num, bbox_labels, bboxes, bbox_features = batch_data

                for idx, image_id in enumerate(id_batch):
                    print("image: image_id={0:6d}, width={1:4d}, height={2:4d}, "
                          "feature_shape={3:4d}, bbox_features_shape={4:}"
                          "\nbbox: num={5:2d}, labels={6:}, bboxes={7:}, features={8:}".
                          format(image_id, width_batch[idx], height_batch[idx],
                                 len(feature_batch[idx]),
                                 shape_batch[idx], bbox_num[idx],
                                 len(bbox_labels[idx]),
                                 len(bboxes[idx]) // 4,
                                 bbox_features[idx]))

                step += 1
            except tf.errors.OutOfRangeError:  # ==> "End of validation dataset"
                print("data reader finished at step={0}".format(step))
                break


if __name__ == '__main__':
    tf.app.run()
