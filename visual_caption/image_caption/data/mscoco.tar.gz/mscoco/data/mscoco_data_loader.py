# -*- coding:utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals  # compatible with python3 unicode coding

import json
import os
from collections import namedtuple

import nltk
import tensorflow as tf

from tf_visgen.mscoco.data.mscoco_data_config import MSCOCODataConfig
from tf_visgen.utils.decorator_utils import timeit

ImageMetadata = namedtuple("ImageMetadata",
                           ["image_id", "filename", "captions"])


class MSCOCODataLoader(object):
    """
    load mscoco data raw data
    """

    def __init__(self):
        self.data_config = MSCOCODataConfig()

    def _process_caption(self, caption):
        """Processes a caption string into a list of tonenized words.
        Args:
          caption: A string caption.
        Returns:
          A list of strings; the tokenized caption.
        """
        tokenized_caption = [self.data_config.token_start]
        tokenized_caption.extend(nltk.tokenize.word_tokenize(caption.lower()))
        tokenized_caption.append(self.data_config.token_end)
        return tokenized_caption

    @timeit
    def _load_and_process_metadata(self, captions_file, image_dir):
        """Loads image metadata from a JSON file and processes the captions.

        Args:
          captions_file: JSON file containing caption annotations.
          image_dir: Directory containing the image files.

        Returns:
          A list of ImageMetadata.
        """
        with tf.gfile.FastGFile(captions_file, "r") as f:
            caption_data = json.load(f)

        # Extract the filenames.
        id_to_filename = [(x["id"], x["file_name"]) for x in caption_data["images"]]

        # Extract the captions. Each image_id is associated with multiple captions.
        id_to_captions = {}
        for annotation in caption_data["annotations"]:
            image_id = annotation["image_id"]
            caption = annotation["caption"]
            id_to_captions.setdefault(image_id, [])
            id_to_captions[image_id].append(caption)

        assert len(id_to_filename) == len(id_to_captions)
        assert set([x[0] for x in id_to_filename]) == set(id_to_captions.keys())
        print("Loaded caption metadata for %d images from %s" %
              (len(id_to_filename), captions_file))

        # Process the captions and combine the data into a list of ImageMetadata.
        print("Processing captions.")
        image_metadata = []
        num_captions = 0
        for image_id, base_filename in id_to_filename:
            filename = os.path.join(image_dir, base_filename)
            captions = [self._process_caption(c) for c in id_to_captions[image_id]]
            image_metadata.append(ImageMetadata(image_id, filename, captions))
            num_captions += len(captions)
        print("Finished processing %d captions for %d images in %s" %
              (num_captions, len(id_to_filename), captions_file))

        return image_metadata

    @timeit
    def load_metadata(self, captions_file, image_dir):
        image_metadata = self._load_and_process_metadata(captions_file, image_dir)
        return image_metadata

    @timeit
    def load_train(self):
        train_image_metadata = self.load_metadata(
            captions_file=self.data_config.captions_train_file,
            image_dir=self.data_config.train_image_dir)
        return train_image_metadata

    @timeit
    def load_valid(self):
        valid_metadata = self.load_metadata(
            captions_file=self.data_config.captions_valid_file,
            image_dir=self.data_config.train_image_dir)
        return valid_metadata


def main(_):
    data_loader = MSCOCODataLoader()
    data_gen = data_loader.load_train()
    for batch, batch_data in enumerate(data_gen):
        print("batch={}".format(batch))
        for idx, data in enumerate(batch_data):
            print("\tidx:{}, data:{}".format(idx, data))


if __name__ == '__main__':
    tf.app.run()
