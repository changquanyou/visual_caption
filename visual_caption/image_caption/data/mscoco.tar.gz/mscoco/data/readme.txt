# data processing api for mscoco dataset

## mscoco_data_loader
   load mscoco metadata(.json) from mscoco raw dataset
   used by mscoco_data_detector

## mscoco_data_detector
   detect bbox regions for each image in mscoco dataset
   and save the proposed bboxes data(.json) to ${mscoco}/detect/
   ##supported with faster_rcnn_detector

## mscoco_data_builder
    convert data in ${mscoco}/detect into tfrecords
    and save these tfrecord data into ${mscoco}/tf_record
    ## supported with inception_resnet_v2

## mscoco_data_reader
   read batched tfrecord data from ${mscoco}/tf_record
