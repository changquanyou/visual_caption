# -*- coding:utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals  # compatible with python3 unicode coding

import os

import ijson.backends.yajl2_cffi as ijson
import numpy as np
import tensorflow as tf

from object_detection.utils import dataset_util
from tf_visgen.base.data.base_data_builder import BaseDataBuilder
from tf_visgen.mscoco.data.mscoco_data_config import MSCOCODataConfig
from tf_visgen.mscoco.data.mscoco_data_loader import MSCOCODataLoader
from tf_visgen.utils import image_utils
from tf_visgen.visgen.feature.feature_extractor import FeatureExtractor


class MSCOCODataBuilder(BaseDataBuilder):
    def __init__(self, data_config):
        super(MSCOCODataBuilder, self).__init__(data_config)

        self.data_loader = MSCOCODataLoader()
        self.feature_extractor = FeatureExtractor()

        pass

    def _to_tf_example(self, image_data):
        """
        Convert python dictionary format data of one image to tf.Example proto.
        Args:
            image_data: information of one image, include bounding box, labels of bounding box,\
                height, width, encoded pixel data.
        Returns:
            example: The converted tf.Example
        """
        image_id = image_data['image_id']
        image_raw_data = image_data['image_raw_data']

        image_height = image_data['height']
        image_width = image_data['width']
        image_depth = image_data['depth']

        bbox_labels = image_data["labels"]
        bboxes = image_data['bboxes']
        bbox_number = len(bboxes)

        image_feature = self.feature_extractor.get_feature_from_rawdata(image_raw_data)

        bbox_raw_data_list = list()
        for bbox in bboxes:
            [xmin, ymin, width, height] = bbox
            x = xmin * image_width
            y = ymin * image_height
            x_width = width * image_width
            y_height = height * image_height
            bbox_raw_data = image_utils.crop_image(
                image_raw_data, xmin=x, ymin=y,
                width=x_width, height=y_height)
            bbox_raw_data_list.append(bbox_raw_data)

        bbox_features = self.feature_extractor.get_feature_from_rawdata_list(
            bbox_raw_data_list)

        bbox_features_data = np.reshape(bbox_features, (-1))
        bboxes_data = np.reshape(bboxes, (-1))

        example = tf.train.Example(features=tf.train.Features(
            feature={
                # image data
                'image/image_id': dataset_util.int64_feature(image_id),

                'image/height': dataset_util.int64_feature(image_height),
                'image/width': dataset_util.int64_feature(image_width),
                'image/depth': dataset_util.int64_feature(image_depth),

                'image/raw_data': dataset_util.bytes_feature(image_raw_data.tobytes()),
                'image/feature': dataset_util.bytes_feature(image_feature.tobytes()),

                # bbox
                'bbox/number': dataset_util.int64_feature(bbox_number),
                'bbox/labels': dataset_util.int64_list_feature(bbox_labels),
                'bbox/bboxes': dataset_util.float_list_feature(bboxes_data),
                'bbox/bbox_features': dataset_util.float_list_feature(bbox_features_data)
            }))
        return example

    def _write(self, tf_writer, tf_batch):
        for tf_example in tf_batch:
            tf_writer.write(tf_example.SerializeToString())
        print("saved {} tf_records".format(len(tf_batch)))
        pass

    def build_train_data(self):

        data_gen = self.data_loader.load_train()
        train_tfrecord_file = os.path.join(
            self.data_config.train_data_dir, 'train.tfrecords')
        tf_writer = tf.python_io.TFRecordWriter(train_tfrecord_file)

        tf_batch = list()
        tf_batch_size = 100

        image_count = 0
        for batch, batch_data in enumerate(data_gen):
            # for each image data
            for idx, image_data in enumerate(batch_data):
                tf_example = self._to_tf_example(image_data)
                image_count += 1
                tf_batch.append(tf_example)
                if len(tf_batch) == tf_batch_size:
                    self._write(tf_writer=tf_writer,
                                tf_batch=tf_batch)
                    print("converted {} images to tf_example".format(image_count))
                    tf_batch = list()

        if len(tf_batch) > 0:
            self._write(tf_writer=tf_writer,
                        tf_batch=tf_batch)

        del tf_batch

        pass


class COCOBBoxTFRecordBuilder(BaseDataBuilder):
    def __init__(self, data_config):
        super(COCOBBoxTFRecordBuilder, self).__init__(data_config)

        # visual feature extractor based on inception_resnet_v2
        self.feature_extractor = FeatureExtractor()
        pass

    def _to_tf_example(self, image_data):
        """
        Convert python dictionary format data of one image to tf.Example proto.
        Args:
            image_data: information of one image, include
                bounding box, labels of bounding box,
                height, width, encoded pixel data.
        Returns:
            example: The converted tf.Example
        """
        image_id = image_data['image_id']
        image_path = image_data['image_filepath']
        image_raw_data = image_utils.load_image(image_path)
        (image_height, image_width, image_depth) = image_raw_data.shape
        image_feature = self.feature_extractor.get_feature_from_rawdata(image_raw_data)

        bboxes = image_data['bboxes']

        bbox_number = len(bboxes)
        bbox_raw_data_list = list()
        bbox_labels_ids = list()
        bbox_labels_names = list()

        bbox_list = list()
        for bbox in bboxes:
            xmin = bbox['x_min']
            ymin = bbox['y_min']
            xmax = bbox['x_max']
            ymax = bbox['y_max']

            bbox_list.append([xmin, ymin, xmax, ymax])

            bbox_labels_ids.append(bbox['class_id'])
            bbox_labels_names.append(bbox['class_name'])

            x_width = xmax - xmin
            y_height = ymax - ymin
            bbox_raw_data = image_utils.crop_image(
                image_raw_data, xmin=xmin, ymin=ymin,
                width=x_width, height=y_height)
            bbox_raw_data_list.append(bbox_raw_data)

        bboxes_data = np.reshape(bbox_list, (-1))

        bbox_features = self.feature_extractor.get_feature_from_rawdata_list(
            bbox_raw_data_list)
        bbox_features = np.asarray(bbox_features)

        # bbox_features = np.reshape(bbox_features, (-1))

        example = tf.train.Example(features=tf.train.Features(
            feature={
                # image data
                'image/image_id': dataset_util.int64_feature(image_id),

                'image/height': dataset_util.int64_feature(image_height),
                'image/width': dataset_util.int64_feature(image_width),
                'image/depth': dataset_util.int64_feature(image_depth),

                # 'image/raw_data': dataset_util.bytes_feature(image_raw_data.tobytes()),
                'image/feature': dataset_util.bytes_feature(image_feature.tobytes()),

                # bbox
                'bbox/number': dataset_util.int64_feature(bbox_number),
                'bbox/labels': dataset_util.int64_list_feature(bbox_labels_ids),
                'bbox/bboxes': dataset_util.int64_list_feature(bboxes_data),
                'bbox/features': dataset_util.bytes_feature(bbox_features.tobytes())

            }))
        return example

    def _write(self, tf_writer, tf_batch):
        for tf_example in tf_batch:
            tf_writer.write(tf_example.SerializeToString())
        print("saved {} tf_records".format(len(tf_batch)))
        pass

    def _load_detect_data(self, detected_metadata_file, batch_size):
        batch_data = list()
        with open(file=detected_metadata_file, mode='rb') as f:
            data_gen = ijson.items(f, "item")
            for data in data_gen:
                batch_data.append(data)
                if len(batch_data) == batch_size:
                    yield batch_data
                    batch_data = list()
        if len(batch_data) > 0:
            yield batch_data
        del batch_data

    def _build_tfrecords(self,detected_data_file,tfrecord_file):
        data_gen = self._load_detect_data(detected_data_file, batch_size=3)
        tf_writer = tf.python_io.TFRecordWriter(tfrecord_file)
        tf_batch = list()
        tf_batch_size = 100  # batch size for writer
        image_count = 0
        for batch, batch_data in enumerate(data_gen):
            # for each image data
            for idx, image_data in enumerate(batch_data):
                tf_example = self._to_tf_example(image_data)
                image_count += 1
                tf_batch.append(tf_example)
                if len(tf_batch) == tf_batch_size:
                    self._write(tf_writer=tf_writer,
                                tf_batch=tf_batch)
                    print("converted {} images to tf_example file {}"
                          .format(image_count, tfrecord_file))
                    tf_batch = list()

        if len(tf_batch) > 0:
            self._write(tf_writer=tf_writer,
                        tf_batch=tf_batch)
        del tf_batch




    def build_train_data(self):
        detect_file = self.data_config.detect_train_file
        data_gen = self._load_detect_data(detect_file, batch_size=3)
        train_tfrecord_file = os.path.join(
            self.data_config.train_data_dir, 'train.tfrecords')
        tf_writer = tf.python_io.TFRecordWriter(train_tfrecord_file)

        tf_batch = list()
        tf_batch_size = 100  # batch size for writer
        image_count = 0
        for batch, batch_data in enumerate(data_gen):
            # for each image data
            for idx, image_data in enumerate(batch_data):
                tf_example = self._to_tf_example(image_data)
                image_count += 1
                tf_batch.append(tf_example)
                if len(tf_batch) == tf_batch_size:
                    self._write(tf_writer=tf_writer,
                                tf_batch=tf_batch)
                    print("converted {} images to tf_example file {}"
                          .format(image_count, train_tfrecord_file))
                    tf_batch = list()

        if len(tf_batch) > 0:
            self._write(tf_writer=tf_writer,
                        tf_batch=tf_batch)
        del tf_batch
        pass


def main(_):
    data_config = MSCOCODataConfig()
    data_builder = COCOBBoxTFRecordBuilder(data_config)
    data_builder.build_train_data()


if __name__ == '__main__':
    tf.app.run()
