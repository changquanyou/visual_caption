import os

from tf_visgen.base.data.base_data_config import BaseDataConfig


TOKEN_BEGIN = '<s>'
TOKEN_END = '</s>'
TOKEN_UNKNOWN = '<unk>'
TOKEN_PAD = '<pad>'


class MSCOCODataConfig(BaseDataConfig):
    def __init__(self):
        super(MSCOCODataConfig, self).__init__(
            model_name="mscoco")

        #
        self.dim_visual_feature = 1536

        # special token for sequence data
        self.token_start = TOKEN_BEGIN
        self.token_end = TOKEN_END
        self.token_unknown = TOKEN_UNKNOWN
        self.token_pad = TOKEN_PAD


        self.mscoco_data_dir = os.path.join(self.base_data_dir, "mscoco")
        self.mscoco_annotations_dir = os.path.join(
            self.mscoco_data_dir, "annotations")

        # for captions
        self.captions_train_file = os.path.join(
            self.mscoco_annotations_dir, "captions_train2014.json")
        self.captions_valid_file = os.path.join(
            self.mscoco_annotations_dir, "captions_val2014.json")

        # for instances
        self.instances_train_file = os.path.join(
            self.mscoco_annotations_dir, "instances_train2014.json")
        self.instances_valid_file = os.path.join(
            self.mscoco_annotations_dir, "instances_val2014.json")

        # for images
        self.image_dir = os.path.join(self.mscoco_data_dir, "images")
        self.train_image_dir = os.path.join(self.image_dir, "train2014")
        self.valid_image_dir = os.path.join(self.image_dir, "val2014")


        # for image region detection
        self.detect_dir = os.path.join(self.mscoco_data_dir,"detect")
        self.detect_train_file = os.path.join(self.detect_dir,'detect_train.json')
        self.detect_valid_file = os.path.join(self.detect_dir,'detect_valid.json')

        # for tf_records outputs
        self.tf_record_dir = os.path.join(self.mscoco_data_dir, "tf_record")
        self.train_data_dir = os.path.join(self.tf_record_dir, "train")
        self.valid_data_dir = os.path.join(self.tf_record_dir, 'valid')

        self.batch_size = 100
